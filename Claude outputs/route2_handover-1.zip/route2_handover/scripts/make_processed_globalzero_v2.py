"""make_processed_globalzero_v2.py -- rebuild TestXXRunYY_processed_globalzero.xlsx from the raw SAFEGo channel files.

v2 (5 Oct 2026) replaces the recipe that produced the earlier processed files:
    OLD : m = midpoint tributary split of a 1133 kg wall (rho 1619) x 2.317348, the factor having been
          CALIBRATED so that Run 24 of US-1 reaches the 29.5 kN reported in the paper; and the wall
          channels were taken as RELATIVE to the table, with ch12 added to make them absolute.
    v2  : masses from the group's sheet -- wall 13.16 kN at gamma 18.8 kN/m3 (1340 kg) split 1/4-1/2-1/4
          between the top-quarter / middle / bottom-quarter accelerometers, + 120 kg slab at each quarter
          level, + 151.4 kg loading beam lumped into the top quarter; springs (10.35 kN) excluded.
          No factor. The wall channels 15/16/17 are ABSOLUTE as recorded (check_accel_abs_vs_rel.py,
          Test9Run24 and Test12Run24: all three track ch12 in the 0.5-3 Hz band), so ch12 is NOT added.

    U_avg [m]      = 0.5 (ch3 + ch4) - Z0        Z0 = 0.5 (ch3 + ch4) at the first finite sample of RUN 1
                                                 (ch5 is NOT subtracted: the potentiometer frames ride on the table)
    base_shear_N   = g0 * (m15 ch15 + m16 ch16 + m17 ch17)       channels in g, absolute

Raw file layout: row 1 = [None, 'Time', 1, 2, ..., 17]; data from row 2.
Usage:
    python make_processed_globalzero_v2.py Test9  <raw_dir> <out_dir>
    python make_processed_globalzero_v2.py Test12 <raw_dir> <out_dir>
    python make_processed_globalzero_v2.py Test9  <raw_dir> <out_dir> --compare <old_processed_dir>
        (prints, per run, old vs new peak base shear so the change is traceable)
Writes <out_dir>/TestXXRunYY_processed_globalzero.xlsx with the masses and the convention recorded in every file.
"""
import sys, os, re, glob
import numpy as np
import openpyxl

G0 = 9.81
M15, M16, M17 = 455.03, 670.07, 606.47      # kg, group's sheet (see header)
MASS_SCALE = 1.0
ACCEL_CONVENTION = "absolute as recorded (ch12 not added)"

def load_raw(path):
    ws = openpyxl.load_workbook(path, read_only=True).worksheets[0]
    it = ws.iter_rows(values_only=True); hdr = next(it)
    col = {}
    for j, h in enumerate(hdr):
        if h is None: continue
        if isinstance(h, str) and h.strip().lower() == "time": col["time"] = j
        else:
            try: col[int(float(h))] = j
            except (TypeError, ValueError): pass
    for k in ("time", 3, 4, 15, 16, 17):
        if k not in col: raise KeyError("{}: column {} not found in row 1".format(os.path.basename(path), k))
    rows = [r for r in it if r[col["time"]] is not None]
    A = np.array([[r[j] if (j < len(r) and r[j] is not None) else np.nan for j in range(len(hdr))] for r in rows], float)
    return A[:, col["time"]], {k: A[:, j] for k, j in col.items() if k != "time"}

def run_no(path):
    m = re.search(r"Run0*(\d+)", os.path.basename(path), re.I); return int(m.group(1)) if m else None

def main():
    if len(sys.argv) < 4:
        print(__doc__); sys.exit(1)
    test, raw_dir, out_dir = sys.argv[1], sys.argv[2], sys.argv[3]
    cmp_dir = sys.argv[sys.argv.index("--compare") + 1] if "--compare" in sys.argv else None
    os.makedirs(out_dir, exist_ok=True)
    files = sorted([f for f in glob.glob(os.path.join(raw_dir, test + "Run*.xlsx")) if "processed" not in f.lower() and run_no(f)], key=run_no)
    if not files: raise FileNotFoundError("no {}RunNN.xlsx in {}".format(test, raw_dir))
    # global zero from run 1
    r1 = [f for f in files if run_no(f) == 1]
    if not r1: raise FileNotFoundError("{}Run1.xlsx is needed for the global zero".format(test))
    t1, ch1 = load_raw(r1[0]); u1 = 0.5 * (ch1[3] + ch1[4]); Z0 = float(u1[np.isfinite(u1)][0])
    print("{}: global zero Z0 = 0.5(ch3+ch4) at t0 of run 1 = {:.8f} m".format(test, Z0))
    print("masses m15/m16/m17 = {} / {} / {} kg (sum {:.1f}), scale {}, channels {}".format(M15, M16, M17, M15 + M16 + M17, MASS_SCALE, ACCEL_CONVENTION))
    for f in files:
        n = run_no(f); t, ch = load_raw(f)
        U = 0.5 * (ch[3] + ch[4]) - Z0
        V = G0 * MASS_SCALE * (M15 * ch[15] + M16 * ch[16] + M17 * ch[17])
        wb = openpyxl.Workbook(); ws = wb.active
        ws.append(["Time", "U_avg", "base_shear_N", "base_shear_kN", "mass_scale", "m15_kg", "m16_kg", "m17_kg", "accel_convention", "Z0_m"])
        for i in range(len(t)):
            ws.append([float(t[i]), float(U[i]), float(V[i]), float(V[i]) / 1e3, MASS_SCALE, M15, M16, M17, ACCEL_CONVENTION if i == 0 else None, Z0 if i == 0 else None])
        out = os.path.join(out_dir, "{}Run{}_processed_globalzero.xlsx".format(test, n)); wb.save(out)
        line = "  run {:2d}: peak U {:7.3f} mm  peak V {:6.2f} kN".format(n, np.nanmax(np.abs(U)) * 1e3, np.nanmax(np.abs(V)) / 1e3)
        if cmp_dir:
            old = os.path.join(cmp_dir, "{}Run{}_processed_globalzero.xlsx".format(test, n))
            if os.path.isfile(old):
                wso = openpyxl.load_workbook(old, read_only=True).worksheets[0]
                vo = np.array([r[3] for r in wso.iter_rows(min_row=2, values_only=True) if r[3] is not None], float)
                line += "   (old file: {:6.2f} kN, old/new {:.2f})".format(np.nanmax(np.abs(vo)), np.nanmax(np.abs(vo)) / (np.nanmax(np.abs(V)) / 1e3))
        print(line)
    print("-> {} files in {}".format(len(files), out_dir))

if __name__ == "__main__":
    main()
